package com.app.arjav.score.keeper;

import static com.app.arjav.score.local.Constant.IS_DARKI_MODE;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

public class SettingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        //chheck if is dark mode than is show black theme
        checkTheme();
    }


    public void onBack(View view) {
        onBackPressed();
    }

    public void saveCurrentSetting(View view) {
        //This method is save currrent data into local store

        if (MainActivity.listener!=null){
            MainActivity.listener.onSaveCurrentSettings();
        }

        Toast.makeText(SettingActivity.this, "Save data", Toast.LENGTH_SHORT).show();
    }

    public void clearCurrentSetting(View view) {
        //This method is clear currrent data from local store

        if (MainActivity.listener!=null){
            MainActivity.listener.onClearCurrentSettings();
        }

        Toast.makeText(SettingActivity.this, "Clear data", Toast.LENGTH_SHORT).show();

    }


    private void checkTheme() {
        if (getIntent().getBooleanExtra(IS_DARKI_MODE,false)){
            findViewById(R.id.toolbar).setBackgroundColor(ContextCompat.getColor(this,R.color.black));
            findViewById(R.id.btnSave).setBackgroundColor(ContextCompat.getColor(this,R.color.black));
            findViewById(R.id.btnClear).setBackgroundColor(ContextCompat.getColor(this,R.color.black));


            //update status bar
            Window window = this.getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(ContextCompat.getColor(this,R.color.black));
        }
    }
}
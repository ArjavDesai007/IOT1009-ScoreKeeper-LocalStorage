package com.app.arjav.score.keeper;

public interface Listener
{
    void onSaveCurrentSettings();
    void onClearCurrentSettings();
}

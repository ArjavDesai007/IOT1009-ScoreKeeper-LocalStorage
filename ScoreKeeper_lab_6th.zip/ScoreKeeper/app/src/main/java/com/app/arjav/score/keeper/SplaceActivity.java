package com.app.arjav.score.keeper;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

public class SplaceActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splace);
        animation();
        loadNextScreen();
    }

    private void loadNextScreen() {
        new Handler().postDelayed(() ->
                {
                    startActivity(new Intent(SplaceActivity.this,MainActivity.class));
                    finish();
                }

                ,1500);
    }

    private void animation() {

        Animation hide = AnimationUtils.loadAnimation(this, R.anim.top_to_bottom);
        findViewById(R.id.icon).startAnimation(hide);
    }
}
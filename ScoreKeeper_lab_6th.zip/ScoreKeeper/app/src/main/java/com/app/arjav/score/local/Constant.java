package com.app.arjav.score.local;

public class Constant {

    // PREFERENCE DATA NAME KEY
    public static final String SCORE_KEEPER_DATABASE = "SCORE_KEEPER_DATABASE";

    // TEAM SCORE KEY
    public static final String SCORE_TEAM_ABC = "SCORE_TEAM_ABC";
    public static final String SCORE_TEAM_XYZ = "SCORE_TEAM_XYZ";

    // POINT NUMBER KEY
    public static final String SCORE_POINT_KEY = "SCORE_POINT_KEY";

    //
    public static final String IS_DARKI_MODE = "isDarkMode";
}

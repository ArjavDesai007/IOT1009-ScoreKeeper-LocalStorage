package com.app.arjav.score.keeper;

import static com.app.arjav.score.local.Constant.IS_DARKI_MODE;
import static com.app.arjav.score.local.Constant.SCORE_KEEPER_DATABASE;
import static com.app.arjav.score.local.Constant.SCORE_POINT_KEY;
import static com.app.arjav.score.local.Constant.SCORE_TEAM_ABC;
import static com.app.arjav.score.local.Constant.SCORE_TEAM_XYZ;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.app.arjav.score.local.Constant;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.switchmaterial.SwitchMaterial;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener,Listener {


    // Its for radio buttons point
    private int POINT = 1;

    // Tracks the score for Team ABC
    private int scoreTeamABC = 0;
    // Tracks the score for Team XYZ
    private int scoreTeamXYZ = 0;

    // TextView that displays Team A score
    private TextView mTeamABCScoreView;
    // TextView that displays Team B score
    private TextView mTeamXYZScoreView;

    //Plus button for team XYZ
    private TextView plusButtonXYZ;
    //Minus button for team XYZ
    private TextView minusButtonXYZ;

    //Plus button for team ABC
    private TextView plusButtonABC;
    //Minus button for team ABC
    private TextView minusButtonABC;
    private SwitchMaterial themeChangeSwitch;
    private RelativeLayout toolbar;
    private Button resetButton;
    private RadioGroup rg;

    //open drawer menu button
    private ImageView btnOpenMenu;

    private DrawerLayout navDrawer;
    private NavigationView navigationDrawer;

    // listener for save and clear current data
    public static Listener listener;
    private SharedPreferences.Editor editor;
    private RadioButton point1,point2,point3;
    private boolean isDarkMode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        createLocalData();

        listener = this;

        navigationDrawer = findViewById(R.id.navigationDrawer);
        navigationDrawer.setNavigationItemSelectedListener(this);

        //drawer layout id
        navDrawer = findViewById(R.id.navDrawer);

        //open drawer menu button
        btnOpenMenu = findViewById(R.id.btnOpenMenu);

        // Team ABC score view
        mTeamABCScoreView = findViewById(R.id.team_a_score);
        //Team XYZ score view
        mTeamXYZScoreView = findViewById(R.id.team_b_score);


        //Plus button for team ABC
        plusButtonABC = findViewById(R.id.plus_1_team_abc);
        //Minus button for team ABC
        minusButtonABC = findViewById(R.id.minus_1_team_abc);


        //Plus button for team XYZ
        plusButtonXYZ = findViewById(R.id.plus_1_team_xyz);
        //Minus button for team XYZ
        minusButtonXYZ = findViewById(R.id.minus_1_team_xyz);

        // switch for change theme color
        themeChangeSwitch = findViewById(R.id.themeChangeSwitch);

        // tool bar for score keeper screen
        toolbar = findViewById(R.id.toolbar);


        //reset button
        resetButton = findViewById(R.id.resetButton);

        rg = (RadioGroup) findViewById(R.id.radioGroup);

        point1 =  rg.findViewById(R.id.point1);
        point2 =  rg.findViewById(R.id.point2);
        point3 =  rg.findViewById(R.id.point3);

        // Radio group for multi point selection
        rg.setOnCheckedChangeListener((group, checkedId) -> {
            switch(checkedId){
                case R.id.point1:
                     POINT = 1;
                     updateButton(POINT);
                    // Its increase point 1 from radio button
                    break;
                case R.id.point2:
                     POINT = 2;
                    updateButton(POINT);
                    // Its increase point 2 from radio button
                    break;
                case R.id.point3:
                     POINT = 3;
                    updateButton(POINT);
                    // Its increase point 3 from radio button
                    break;
            }
        });


        themeChangeSwitch.setOnCheckedChangeListener((compoundButton, isChecked) -> {

            if (isChecked){
                isDarkMode = true;
                updateUIColor(R.color.black,R.color.black,R.color.color_count);
                updateStatusBar(R.color.black);

            } else {
                isDarkMode = false;
                updateUIColor(R.color.toolbar_bg,R.color.plus_btn_bg,R.color.minus_btn_bg);
                updateStatusBar(R.color.toolbar_bg);
            }

        });

        btnOpenMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(!navDrawer.isDrawerOpen(GravityCompat.END)) {
                    //change navigation drawer header color
                    if (isDarkMode){
                        navigationDrawer.getHeaderView(0).findViewById(R.id.headerBg).setBackgroundColor(ContextCompat.getColor(MainActivity.this,R.color.black));
                    } else {
                        navigationDrawer.getHeaderView(0).findViewById(R.id.headerBg).setBackgroundColor(ContextCompat.getColor(MainActivity.this,R.color.toolbar_bg));

                    }


                    navDrawer.openDrawer(GravityCompat.START);
                }
                else navDrawer.closeDrawer(GravityCompat.END);

            }
        });

    }

    private void createLocalData() {

        //Initilaze local data object
        editor = getSharedPreferences(SCORE_KEEPER_DATABASE, MODE_PRIVATE).edit();

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        // Handle navigation view item clicks here.
        switch (item.getItemId()) {

            case R.id.navSettings: { // click for setting
                Intent intent = new Intent(MainActivity.this,SettingActivity.class);
                intent.putExtra(IS_DARKI_MODE,isDarkMode);
                startActivity(intent);

                break;
            }
            case R.id.navAbout: { // click for about student details
                Toast.makeText(this, "" +
                        "Name : Arjav\n" +
                        "Course Code : IOT-1009", Toast.LENGTH_LONG).show();
                break;
            }
        }
        //close navigation drawer
        navDrawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void updateUIColor(int toolbarColor, int plusButton, int minusButton) {

        toolbar.setBackgroundColor(ContextCompat.getColor(this,toolbarColor));
        resetButton.setBackgroundColor(ContextCompat.getColor(this,toolbarColor));

        plusButtonXYZ.setBackgroundColor(ContextCompat.getColor(this,plusButton));
        plusButtonABC.setBackgroundColor(ContextCompat.getColor(this,plusButton));

        minusButtonXYZ.setBackgroundColor(ContextCompat.getColor(this,minusButton));
        minusButtonABC.setBackgroundColor(ContextCompat.getColor(this,minusButton));
    }


    private void updateStatusBar(int color) {

        Window window = this.getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.setStatusBarColor(ContextCompat.getColor(this,color));
    }

    private void updateButton(int point) {

        // Update both team plus/minus button's according to selected point's of radio button
        plusButtonABC.setText("+"+point+" POINT");
        minusButtonABC.setText("-"+point+" POINT");

        plusButtonXYZ.setText("+"+point+" POINT");
        minusButtonXYZ.setText("-"+point+" POINT");

    }


    public void addPoint(View v) {

        int id = v.getId();
        switch (id) {
            case R.id.plus_1_team_abc:
                // Its plus selected point from team ABC's score
                scoreTeamABC = scoreTeamABC + POINT;
                display(mTeamABCScoreView, scoreTeamABC);
                break;
            case R.id.minus_1_team_abc:
                // Increase the score for Team A by 2 points.
                if (scoreTeamABC == 0){
                    showMessage("Team ABC Score is already zero");
                } else if (scoreTeamABC < POINT){
                    showMessage("Team ABC's Total score is less than selected minus point");
                } else {

                    // Its minus selected point from team ABC's score
                    scoreTeamABC = scoreTeamABC - POINT;
                    display(mTeamABCScoreView, scoreTeamABC);
                }

                break;
            case R.id.plus_1_team_xyz:
                // Its plus selected point from team XYZ's score
                scoreTeamXYZ = scoreTeamXYZ + POINT;
                display(mTeamXYZScoreView, scoreTeamXYZ);
                break;
            case R.id.minus_1_team_xyz:
                //Increase the score for Team B by 2 points.
                if (scoreTeamXYZ == 0){
                    showMessage("Team XYZ Score is already zero");
                } else if (scoreTeamXYZ < POINT){
                    showMessage("Team XYZ's Total score is less than selected minus point");
                } else {

                    // Its minus selected point from team XYZ's score
                    scoreTeamXYZ = scoreTeamXYZ - POINT;
                    display(mTeamXYZScoreView, scoreTeamXYZ);
                }

                break;
        }
    }

    private void showMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();

    }


    public void resetScore(View v) {
        // Its reset both teams score and display zero in score view
        scoreTeamABC = 0;
        scoreTeamXYZ = 0;
        display(mTeamABCScoreView, scoreTeamABC);
        display(mTeamXYZScoreView, scoreTeamXYZ);
    }

    private void display(TextView scoreView, int score) {
        scoreView.setText(String.valueOf(score));
    }

    @Override
    public void onSaveCurrentSettings() {

        editor.putString(SCORE_TEAM_ABC,mTeamABCScoreView.getText().toString());
        editor.putString(SCORE_TEAM_XYZ,mTeamXYZScoreView.getText().toString());
        editor.putInt(SCORE_POINT_KEY,POINT);
        editor.apply();
    }

    @Override
    public void onClearCurrentSettings() {

        //Clear all local data
        editor.clear();
        editor.apply();

    }

    void getSavedData() {

        // get stored data
        SharedPreferences prefs = getSharedPreferences(SCORE_KEEPER_DATABASE, MODE_PRIVATE);

        if (prefs!=null && prefs.getString(SCORE_TEAM_ABC,null)!=null){
            //this if block is get data from local store and print is specific textview

            String mTeamABCScore = prefs.getString(SCORE_TEAM_ABC,null);
            mTeamABCScoreView.setText(mTeamABCScore);
            scoreTeamABC = Integer.parseInt(mTeamABCScore);

            String mTeamXYZScore = prefs.getString(SCORE_TEAM_XYZ,null);
            mTeamXYZScoreView.setText(mTeamXYZScore);
            scoreTeamXYZ = Integer.parseInt(mTeamXYZScore);

            int point = prefs.getInt(SCORE_POINT_KEY,0);
            POINT = point;

            //check radio button point
            if (point == 1){
                point1.setChecked(true);
            } else if (point == 2){
                point2.setChecked(true);
            } else  {
                point3.setChecked(true);
            }

        } else {

            //when data not stored in local store that time its show default data

            mTeamABCScoreView.setText("0");
            scoreTeamABC = 0;

            mTeamXYZScoreView.setText("0");
            scoreTeamXYZ = 0;

            POINT = 1;

            point1.setChecked(true);
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        getSavedData();
    }
}